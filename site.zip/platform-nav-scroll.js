(function () {
  function currentPlatformKey() {
    var cleanPath = location.pathname.replace(/\/+$/, "");
    var slug = (cleanPath.split("/").pop() || "index").toLowerCase().replace(/\.html?$/, "");
    if (slug === "xiaohongshu") return "xhs";
    if (slug === "douyin") return "douyin";
    if (slug === "wechat") return "wechat";
    return "video";
  }

  function initTopPlatformSwitcher() {
    var rail = document.querySelector(".platformRail");
    var header = document.querySelector("main > header, header");
    if (!rail || !header) return;
    var currentKey = currentPlatformKey();
    var platformClass = "platform-" + currentKey;
    var themes = {
      "platform-video": ["#666fa3", "#eef0f8"],
      "platform-xhs": ["#c45462", "#faecef"],
      "platform-douyin": ["#6f657f", "#f1eef5"],
      "platform-wechat": ["#078a4a", "#eaf7f0"]
    };
    document.body.classList.add(platformClass);
    document.documentElement.classList.add(platformClass);
    header.classList.add("platformHeader");
    var platforms = [
      { href: "index.html", label: "视频号", key: "video" },
      { href: "xiaohongshu.html", label: "小红书", key: "xhs" },
      { href: "douyin.html", label: "抖音号", key: "douyin" },
      { href: "wechat.html", label: "公众号", key: "wechat" }
    ];
    rail.innerHTML = platforms.map(function (item) {
      return '<a href="' + item.href + '"' + (currentKey === item.key ? ' class="active" aria-current="page"' : '') + '>' + item.label + '</a>';
    }).join("");
    rail.classList.add("topPlatformSwitcher");
    rail.style.setProperty("--platform-accent", themes[platformClass][0]);
    rail.style.setProperty("--platform-accent-soft", themes[platformClass][1]);
    var activeLink = rail.querySelector("a.active");
    if (activeLink) {
      activeLink.style.color = themes[platformClass][0];
      activeLink.style.backgroundColor = themes[platformClass][1];
      activeLink.style.boxShadow = "inset 0 0 0 1px " + themes[platformClass][0] + "30, 0 2px 8px " + themes[platformClass][0] + "24";
      activeLink.style.fontWeight = "750";
    }
    var actions = header.querySelector(".actions");
    header.insertBefore(rail, actions || null);
  }

  function initMobilePlatformDock() {
    if (document.querySelector(".mobilePlatformDock")) return;
    var currentKey = currentPlatformKey();
    var platforms = [
      { href: "index.html", label: "视频号", key: "video", icon: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="13" height="14" rx="3"></rect><path d="m16 10 5-3v10l-5-3z"></path></svg>' },
      { href: "xiaohongshu.html", label: "小红书", key: "xhs", icon: '<svg viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="18" rx="4"></rect><path d="M8 8h8M8 12h8M8 16h5"></path></svg>' },
      { href: "douyin.html", label: "抖音号", key: "douyin", icon: '<svg viewBox="0 0 24 24"><path d="M14 4v10.2a4.2 4.2 0 1 1-3.2-4.1"></path><path d="M14 4c1 3 2.8 4.5 6 4.8"></path></svg>' },
      { href: "wechat.html", label: "公众号", key: "wechat", icon: '<svg viewBox="0 0 24 24"><path d="M12.5 6.3C11.5 4.3 9.2 3 6.7 3 3.5 3 1 5.1 1 7.8c0 1.5.8 2.8 2.1 3.7l-.6 2.1 2.3-1.2c.6.2 1.2.3 1.9.3"></path><path d="M23 13.7c0-3.2-3.1-5.8-7-5.8s-7 2.6-7 5.8 3.1 5.8 7 5.8c.8 0 1.6-.1 2.3-.4l2.7 1.4-.7-2.5c1.7-1 2.7-2.6 2.7-4.3z"></path></svg>' }
    ];
    var dock = document.createElement("nav");
    dock.className = "mobilePlatformDock";
    dock.setAttribute("aria-label", "平台切换");
    dock.innerHTML = platforms.map(function (item) {
      var active = currentKey === item.key;
      return '<a href="' + item.href + '"' + (active ? ' class="active" aria-current="page"' : '') + '>' + item.icon + '<span>' + item.label + '</span></a>';
    }).join("");
    document.body.appendChild(dock);
  }

  function initPlatformNav() {
    var nav = document.querySelector("aside nav");
    if (!nav) return;

    nav.querySelectorAll('button[data-target*="top-section"]').forEach(function (button) {
      button.remove();
    });

    var buttons = Array.from(nav.querySelectorAll("button[data-target]"));
    var sections = buttons.map(function (button) {
      return document.getElementById(button.dataset.target);
    });

    function updateActiveNav() {
      var activeIndex = 0;
      var marker = window.scrollY + Math.min(240, window.innerHeight * 0.3);
      sections.forEach(function (section, index) {
        if (section && section.offsetTop <= marker) activeIndex = index;
      });
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 24) {
        activeIndex = buttons.length - 1;
      }
      buttons.forEach(function (button, index) {
        button.classList.toggle("selected", index === activeIndex);
      });
    }

    buttons.forEach(function (button) {
      button.addEventListener("click", function () {
        var section = document.getElementById(button.dataset.target);
        if (section) section.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
    window.addEventListener("scroll", updateActiveNav, { passive: true });
    window.addEventListener("resize", updateActiveNav);
    updateActiveNav();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      initTopPlatformSwitcher();
      initMobilePlatformDock();
      initPlatformNav();
    });
  } else {
    initTopPlatformSwitcher();
    initMobilePlatformDock();
    initPlatformNav();
  }
})();
