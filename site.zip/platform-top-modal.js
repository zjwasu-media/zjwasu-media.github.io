(function(){
  "use strict";
  var configs=[
    {panel:"#xhs-top-section",data:"XHS_DATA",value:"views",unit:"阅读",title:"数据 TOP 内容"},
    {panel:"#dy-top-section",data:"DOUYIN_DATA",value:"plays",unit:"播放",title:"数据 TOP 内容"},
    {panel:"#wx-top-section",data:"WECHAT_DATA",value:"reads",unit:"阅读",title:"数据 TOP 内容"}
  ];
  var c=configs.find(function(x){return document.querySelector(x.panel)});if(!c)return;
  var panel=document.querySelector(c.panel),head=panel.querySelector(".panelHead"),data=(window[c.data]||[]).slice();
  var oldRight=head.querySelector(":scope > span"),right=document.createElement("div");right.className="platformTopHeadActions";if(oldRight){oldRight.parentNode.insertBefore(right,oldRight);right.appendChild(oldRight)}else head.appendChild(right);
  var open=document.createElement("button");open.className="platformExpandBtn platformTopExpand";open.type="button";open.title="查看前20条";open.setAttribute("aria-label","查看前20条数据 TOP 内容");open.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H3v5M16 3h5v5M8 21H3v-5M21 16v5h-5"/></svg>';right.appendChild(open);
  var modal=document.createElement("div");modal.className="platformTopModal";modal.setAttribute("aria-hidden","true");modal.innerHTML='<div class="platformTopModalCard" role="dialog" aria-modal="true"><div class="platformTrendModalHead"><div><h2>'+c.title+' · 前20条</h2><p>按'+c.unit+'量降序排列</p></div><button class="platformTrendClose platformTopClose" type="button" aria-label="关闭">×</button></div><div class="platformTopModalGrid"></div></div>';document.body.appendChild(modal);
  function fmt(n){return Number(n||0).toLocaleString("zh-CN")}
  var top=data.sort(function(a,b){return Number(b[c.value]||0)-Number(a[c.value]||0)}).slice(0,20);
  modal.querySelector(".platformTopModalGrid").innerHTML=top.map(function(x,i){var date=(x.date||x.year+"年").slice(0,16),cover=x.cover||"",placeholder=x.hasRealCover===false?" dyPlaceholder":"";return '<article class="platformTopCard"><span class="platformTopRank">'+(i+1)+'</span><img class="platformTopCover'+placeholder+'" src="'+cover+'" alt=""><div class="platformTopInfo"><div class="platformTopTitle">'+x.title+'</div><div class="platformTopMeta">'+date+' · 互动 '+fmt(x.interactions)+'</div></div><div class="platformTopValue">'+fmt(x[c.value])+'<small>'+c.unit+'</small></div></article>'}).join("");
  function show(){modal.classList.add("open");modal.setAttribute("aria-hidden","false");document.body.classList.add("trendModalOpen")}
  function close(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true");document.body.classList.remove("trendModalOpen")}
  open.addEventListener("click",show);modal.querySelector(".platformTopClose").addEventListener("click",close);modal.addEventListener("click",function(e){if(e.target===modal)close()});document.addEventListener("keydown",function(e){if(e.key==="Escape"&&modal.classList.contains("open"))close()});
})();
