(function(){
  "use strict";
  var configs=[
    {range:"#xhsTrendRange",chart:"#xhsTrend",title:"阅读趋势"},
    {range:"#dyTrendRange",chart:"#dyTrend",title:"播放趋势"},
    {range:"#wxTrendRange",chart:"#wxTrend",title:"阅读趋势"}
  ];
  var config=configs.find(function(x){return document.querySelector(x.range)});
  if(!config)return;
  var range=document.querySelector(config.range),sourceEl=document.querySelector(config.chart);
  var actions=document.createElement("div");actions.className="platformTrendActions";
  range.parentNode.insertBefore(actions,range);actions.appendChild(range);
  var open=document.createElement("button");open.className="platformExpandBtn";open.type="button";open.title="放大"+config.title;open.setAttribute("aria-label","放大"+config.title);open.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H3v5M16 3h5v5M8 21H3v-5M21 16v5h-5"/></svg>';actions.appendChild(open);
  var modal=document.createElement("div");modal.className="platformTrendModal";modal.setAttribute("aria-hidden","true");modal.innerHTML='<div class="platformTrendModalCard" role="dialog" aria-modal="true" aria-label="'+config.title+'放大视图"><div class="platformTrendModalHead"><h2>'+config.title+'</h2><button class="platformTrendClose" type="button" aria-label="关闭">×</button></div><div class="platformTrendModalChart"></div></div>';document.body.appendChild(modal);
  var modalChart;
  function sync(){var source=echarts.getInstanceByDom(sourceEl);if(!source)return;if(!modalChart)modalChart=echarts.init(modal.querySelector(".platformTrendModalChart"));modalChart.setOption(source.getOption(),true);modalChart.resize()}
  function show(){modal.classList.add("open");modal.setAttribute("aria-hidden","false");document.body.classList.add("trendModalOpen");requestAnimationFrame(sync)}
  function close(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true");document.body.classList.remove("trendModalOpen")}
  open.addEventListener("click",show);modal.querySelector(".platformTrendClose").addEventListener("click",close);modal.addEventListener("click",function(e){if(e.target===modal)close()});document.addEventListener("keydown",function(e){if(e.key==="Escape"&&modal.classList.contains("open"))close()});range.addEventListener("click",function(){if(modal.classList.contains("open"))requestAnimationFrame(sync)});window.addEventListener("resize",function(){if(modalChart&&modal.classList.contains("open"))modalChart.resize()});
})();
